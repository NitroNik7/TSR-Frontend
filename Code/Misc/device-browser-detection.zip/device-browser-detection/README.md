# Device-browser-detection

#### This repo belongs to my video tutorial demonstrating how can you detect your users browser and devices by using the Library called [Platform.JS](https://github.com/bestiejs/platform.js)

### Watch the demonstration 👇🏼
[![](https://i.ytimg.com/vi/0NSjvxYuKWA/hqdefault.jpg?sqp=-oaymwEZCPYBEIoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&rs=AOn4CLA7tpU7l36Mr6zd1yX8IDRO2YcIdA)](https://www.youtube.com/watch?v=0NSjvxYuKWA "How to Detect Browser and Devices in Javascript | Platform.js")

### Usage ➡

Download Zip or install via `git clone` and the run `index.html` in your browser
